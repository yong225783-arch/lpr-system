import sqlite3
import os
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

DATABASE = os.path.join(os.path.dirname(__file__), 'lpr.db')

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()

    # 車主資料表
    c.execute('''
        CREATE TABLE IF NOT EXISTS owners (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT,
            plate TEXT UNIQUE NOT NULL,
            note TEXT,
            is_blacklist INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # 開門紀錄表
    c.execute('''
        CREATE TABLE IF NOT EXISTS records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            plate TEXT NOT NULL,
            owner_name TEXT,
            result TEXT NOT NULL,
            image_path TEXT,
            note TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # 管理員帳號表
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT DEFAULT 'admin',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # 系統設定表
    c.execute('''
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    ''')

    # 預設管理員帳號 admin / admin123
    c.execute('SELECT * FROM users WHERE username = ?', ('admin',))
    if not c.fetchone():
        c.execute(
            'INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)',
            ('admin', generate_password_hash('admin123'), 'admin')
        )

    conn.commit()
    conn.close()

# ============ 車主管理 ============

def get_owners():
    conn = get_db()
    rows = conn.execute('SELECT * FROM owners ORDER BY created_at DESC').fetchall()
    conn.close()
    return [dict(row) for row in rows]

def get_owner_by_plate(plate):
    conn = get_db()
    row = conn.execute(
        'SELECT * FROM owners WHERE plate = ? AND is_blacklist = 0',
        (plate,)
    ).fetchone()
    conn.close()
    return dict(row) if row else None

def get_owner_by_id(owner_id):
    conn = get_db()
    row = conn.execute('SELECT * FROM owners WHERE id = ?', (owner_id,)).fetchone()
    conn.close()
    return dict(row) if row else None

def add_owner(name, phone, plate, note=''):
    conn = get_db()
    try:
        conn.execute(
            'INSERT INTO owners (name, phone, plate, note) VALUES (?, ?, ?, ?)',
            (name, phone, plate, note)
        )
        conn.commit()
        conn.close()
        return True, '新增成功'
    except sqlite3.IntegrityError:
        conn.close()
        return False, '車牌已存在'

def update_owner(owner_id, name, phone, plate, note, is_blacklist):
    conn = get_db()
    try:
        conn.execute(
            '''UPDATE owners SET name=?, phone=?, plate=?, note=?, is_blacklist=? WHERE id=?''',
            (name, phone, plate, note, is_blacklist, owner_id)
        )
        conn.commit()
        conn.close()
        return True, '更新成功'
    except sqlite3.IntegrityError:
        conn.close()
        return False, '車牌已存在'

def delete_owner(owner_id):
    conn = get_db()
    conn.execute('DELETE FROM owners WHERE id = ?', (owner_id,))
    conn.commit()
    conn.close()

# ============ 開門紀錄 ============

def add_record(plate, owner_name, result, image_path=None, note=''):
    conn = get_db()
    conn.execute(
        'INSERT INTO records (plate, owner_name, result, image_path, note) VALUES (?, ?, ?, ?, ?)',
        (plate, owner_name, result, image_path, note)
    )
    conn.commit()
    conn.close()

def get_records(limit=100, offset=0, plate_filter=None, date_filter=None):
    conn = get_db()
    query = 'SELECT * FROM records WHERE 1=1'
    params = []
    if plate_filter:
        query += ' AND plate LIKE ?'
        params.append(f'%{plate_filter}%')
    if date_filter:
        query += ' AND DATE(created_at) = ?'
        params.append(date_filter)
    query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?'
    params.extend([limit, offset])
    rows = conn.execute(query, params).fetchall()
    conn.close()
    return [dict(row) for row in rows]

def get_record_count(plate_filter=None, date_filter=None):
    conn = get_db()
    query = 'SELECT COUNT(*) FROM records WHERE 1=1'
    params = []
    if plate_filter:
        query += ' AND plate LIKE ?'
        params.append(f'%{plate_filter}%')
    if date_filter:
        query += ' AND DATE(created_at) = ?'
        params.append(date_filter)
    count = conn.execute(query, params).fetchone()[0]
    conn.close()
    return count

# ============ 認證 ============

def verify_user(username, password):
    conn = get_db()
    row = conn.execute(
        'SELECT * FROM users WHERE username = ?', (username,)
    ).fetchone()
    conn.close()
    if row and check_password_hash(row['password_hash'], password):
        return dict(row)
    return None

def change_password(user_id, new_password):
    conn = get_db()
    conn.execute(
        'UPDATE users SET password_hash = ? WHERE id = ?',
        (generate_password_hash(new_password), user_id)
    )
    conn.commit()
    conn.close()

# ============ 設定 ============

def get_setting(key, default=None):
    conn = get_db()
    row = conn.execute('SELECT value FROM settings WHERE key = ?', (key,)).fetchone()
    conn.close()
    return row['value'] if row else default

def set_setting(key, value):
    conn = get_db()
    conn.execute(
        'INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)',
        (key, value)
    )
    conn.commit()
    conn.close()
