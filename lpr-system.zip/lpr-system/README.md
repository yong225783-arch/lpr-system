# 🚗 車牌辨識開門系統

一個專業的車牌辨識自動開門系統，支援網頁管理、多使用者、开壬记录等功能。

## 功能

- ✅ **車牌辨識** - 即時影像辨識（OpenCV + EasyOCR）
- ✅ **自動開門** - 白名單車牌自動開門
- ✅ **網頁管理** - 新增/編輯/刪除車主資料
- ✅ **開門紀錄** - 完整時間、車牌、車主、狀態記錄
- ✅ **手動開門** - 網頁按鈕直接開門
- ✅ **黑白名單** - 支援黑名單封鎖
- ✅ **照片存證** - 開門時自動截圖
- ✅ **多帳號** - 管理員/使用者權限
- ✅ **內網訪問** - 同一網路下任何設備都可開門

## 硬體需求

- Windows 電腦（建議 Intel i3 以上）
- **IP 攝影機**（支援 RTSP，推薦：騰達、水星、小米、TP-Link 等）
- **USB 繼電器模組**（2路 5V，淘寶關鍵字：「USB繼電器模組 2路 5V」）

## 快速開始

### 1. 安裝 Python

到 https://www.python.org/downloads/ 下載 Python 3.10+，安裝時勾選 **Add Python to PATH**。

### 2. 安裝依賴

開啟命令提示字元（CMD），執行：

```bash
cd lpr-system
pip install -r requirements.txt
```

### 3. 確認 IP Cam 的 RTSP 串流位址

每家不同，常見格式：
- **Tenda**: `rtsp://admin:admin123@192.168.1.100:554/stream1`
- **TP-Link**: `rtsp://username:password@IP:554/stream1`
- **小米**: `rtsp://IP:554/live/stream`
- **通用**: `rtsp://IP:554/stream1`

建議先用 VLC 測試能否播放。

### 4. 設定環境變量

```bash
# Windows CMD
set CAMERA_SOURCE=rtsp://admin:password@192.168.1.100:554/stream1
set RELAY_PORT=COM3

# Windows PowerShell
$env:CAMERA_SOURCE="rtsp://admin:password@192.168.1.100:554/stream1"
$env:RELAY_PORT="COM3"
```

### 6. 確認 USB 繼電器 Port

Windows 上插入 USB 繼電器後，到「裝置管理員」→「連接埠」查看，例如 `COM3`。

### 7. 啟動系統

```bash
python main.py
```

### 7. 打開網頁

```
http://localhost:5000
```

- 帳號：`admin`
- 密碼：`admin123`

## 系統架構

```
IP 攝影機 (RTSP) ──→ OpenCV 偵測車牌區域
                         ↓
                   EasyOCR 辨識車牌號碼
                         ↓
                   比對白名單資料庫
                         ↓
                   ✅ 符合 → USB 繼電器 → 開門
                   ❌ 不符合 → 拒絕開門
                         ↓
                   寫入開門紀錄（SQLite）
                         ↓
                   網頁管理介面（任何設備可查詢）
```

## 繼電器接線

```
USB 繼電器                    捲門遲控器
  ┌──────┐                  ┌──────────┐
  │  NO   │ ─────────────── │  按鍵線  │
  │  COM  │ ─────────────── │  GND     │
  │  5V   │ ─────────────── │  5V (可選)│
  └──────┘                  └──────────┘
```

NO = Normal Open（常開）
COM = Common（公共端）

## 目錄結構

```
lpr-system/
├── main.py           # 主程式
├── database.py       # 資料庫操作
├── relay.py          # 繼電器控制
├── requirements.txt  # Python 依賴
├── lpr.db           # SQLite 資料庫（自動建立）
├── captures/        # 開門截圖（自動建立）
├── templates/        # 網頁模板
│   ├── base.html
│   ├── index.html
│   ├── login.html
│   ├── owners.html
│   └── records.html
└── static/
    ├── css/style.css
    └── js/app.js
```

## 網址訪問

在同一部電腦：`http://localhost:5000`

在其他設備（同一網路）：`http://[電腦IP]:5000`

查看電腦 IP：
```bash
ipconfig
```
找「IPv4 位址」，例如 `192.168.1.100`

## 进阶：對接 OpenClaw

可以讓 OpenClaw 透過 HTTP API 發送車牌資料：

```bash
curl -X POST http://localhost:5000/api/check_plate \
  -H "Content-Type: application/json" \
  -d '{"plate": "ABC-1234", "image_path": "/captures/xxx.jpg"}'
```

## 安全建議

- ⚠️ 修改預設密碼（admin123）
- ⚠️ 不要把系統暴露在公共網路
- ⚠️ 定期備份 `lpr.db` 資料庫
- ⚠️ 建議使用 UPS 防止斷電

## 故障排除

**攝像頭無法開啟**
- 確認攝像頭已正確連接
- 確認沒有其他程式在使用攝像頭
- 試著換一個 USB port

**繼電器無反應**
- 確認 COM Port 設定正確
- 確認繼電器已供電（LED 燈亮）
- 確認接線正確

**車牌辨識不準確**
- 調整攝像頭角度和光線
- 確認車牌在畫面中清晰可見
- 考慮使用更高解析度的攝像頭

---

建議後續整合 OpenClaw 的 `web-browsing` 和 `agent-browser-core` Skill，達成語音控制和智能客服功能！
