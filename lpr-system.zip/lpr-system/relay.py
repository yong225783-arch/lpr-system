import serial
import time
import logging
import os

logger = logging.getLogger(__name__)

class RelayController:
    def __init__(self, port=None, baudrate=9600):
        """
        USB 繼電器控制器
        port: COM3 (Windows) 或 /dev/ttyUSB0 (Linux)
        """
        self.port = port
        self.baudrate = baudrate
        self.serial = None
        self._auto_detect()

    def _auto_detect(self):
        """自動偵測 USB 繼電器連接的 COM port"""
        if self.port:
            return
        possible_ports = []
        if os.name == 'nt':  # Windows
            for i in range(1, 21):
                possible_ports.append(f'COM{i}')
        else:  # Linux/Mac
            possible_ports = ['/dev/ttyUSB0', '/dev/ttyUSB1', '/dev/ttyACM0', '/dev/cu.usbserial']

        for p in possible_ports:
            try:
                s = serial.Serial(p, self.baudrate, timeout=1)
                s.close()
                self.port = p
                logger.info(f'自動偵測到繼電器: {p}')
                return
            except:
                continue
        logger.warning('無法自動偵測繼電器，請手動指定 port')

    def _send_command(self, cmd):
        """發送繼電器指令（支援不同品牌的繼電器）"""
        commands = [
            cmd,  # 標準指令
            cmd + b'\r\n',  # 帶換行
            cmd + b'\n',   # 帶換行
        ]
        for c in commands:
            try:
                self.serial.write(c)
                time.sleep(0.3)
                return True
            except:
                continue
        return False

    def connect(self):
        if not self.port:
            return False
        try:
            self.serial = serial.Serial(self.port, self.baudrate, timeout=1)
            time.sleep(0.5)
            return True
        except Exception as e:
            logger.error(f'連接繼電器失敗: {e}')
            return False

    def open_gate(self, duration=1.5):
        """
        觸發繼電器開門
        duration: 開門信號持續時間（秒）
        """
        if not self.serial or not self.serial.is_open:
            if not self.connect():
                logger.error('無法連接繼電器')
                return False
        try:
            # 發送開門信號（根據繼電器型號調整指令）
            # 常見 USB 繼電器指令：relay_on = b'{\xff\x01\x01}' / relay_off = b'{\xff\x01\x00}'
            self.serial.write(b'{\xff\x01\x01}')
            time.sleep(duration)
            self.serial.write(b'{\xff\x01\x00}')
            logger.info(f'開門信號已發送，持續 {duration} 秒')
            return True
        except Exception as e:
            logger.error(f'開門失敗: {e}')
            return False

    def close(self):
        if self.serial and self.serial.is_open:
            self.serial.close()
